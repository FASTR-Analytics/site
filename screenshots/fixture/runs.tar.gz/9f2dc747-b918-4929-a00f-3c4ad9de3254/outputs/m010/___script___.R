#-------------------------------------------------------------------------------------------------------------
# M10: Health Facility Assessment Module
#
# Computes HFA indicators from facility-level survey data. Indicator R code,
# warnings, and metadata are dynamically generated based on the configured
# HFA indicator catalog.
#
# OUTPUT:
#   M10_hfa_results.csv — One row per facility × indicator × time_point
#   M10_hfa_results_carried.csv — Same as M10_hfa_results.csv, plus rounds
#     where an indicator was not measured filled by duplicating the nearest
#     measured round's facility rows (previous round preferred; later round
#     only for leading gaps). carried_from = donor time point (NA on
#     observed rows).
#   M10_hfa_response_status.csv — Response-status companion (don't-know /
#     missing / not-applicable / answered), one row per facility × indicator
#     × time_point. Empty (header only) when the server does not emit
#     __status columns.
#   M10_hfa_results_variants.csv — Per-item breakdown for indicators authored
#     with a variant group: one row per facility × indicator × variant item ×
#     time_point, hfa_indicator = the parent indicator. Empty (header only)
#     when no variant columns are emitted.
#   M10_hfa_results_variants_carried.csv — Same as M10_hfa_results_variants.csv,
#     plus rounds where a (indicator, variant item) pair was not measured
#     filled by duplicating the nearest measured round's facility rows (same
#     donor rule as the main carried output). carried_from = donor time point
#     (NA on observed rows).
#
#-------------------------------------------------------------------------------------------------------------

library(dplyr)
library(tidyr)

print("Starting HFA script...")



# Read and pivot data to wide format
data <- read.csv('../../inputs/datasets/hfa.csv')

# Sampling weight column (added by newer exports; tolerate its absence)
if (!"weight" %in% names(data)) data$weight <- NA_real_

data_wide <- data %>%
  pivot_wider(names_from = variable_id, values_from = value)

# Detect facility columns dynamically
facility_cols <- names(data_wide)[grepl("^(facility_|admin_area_|time_point)", names(data_wide))]

# Convert pivoted variable columns to numeric (they may be character after pivot)
data_wide <- data_wide %>%
  mutate(across(-all_of(facility_cols), as.numeric))

# Resolve sampling weights: weights off, or a facility with no weight row,
# means weight 1 — the weighted formulas then reduce exactly to unweighted ones
if (FALSE) {
  n_no_weight <- sum(is.na(data_wide$weight))
  print(paste0("Facility/time-point rows without a sampling weight (fallback to weight 1): ", n_no_weight))
}
data_wide <- data_wide %>%
  mutate(weight_final = if (FALSE) coalesce(weight, 1) else 1)

# Calculate indicators
results <- data_wide %>%
  mutate(electricity = with(list(
    `%in%` = function(x, table) ifelse(is.na(x), NA, base::`%in%`(x, table)),
    sh_01 = replace(sh_01, sh_01 %in% c(-99, -999999), NA_real_)
  ), case_when(
    time_point == "Round 1" & is.na(sh_01 == "1") ~ NA_real_,
    time_point == "Round 1" & (sh_01 == "1") ~ 1,
    time_point == "Round 1" ~ 0,
    time_point == "Round 2" & is.na(sh_01 == "1") ~ NA_real_,
    time_point == "Round 2" & (sh_01 == "1") ~ 1,
    time_point == "Round 2" ~ 0,
    TRUE ~ NA_real_
  ))) %>%
  mutate(electricity__status = case_when(
    time_point == "Round 1" & (sh_01 %in% c(-99, -999999)) ~ "dont_know",
    time_point == "Round 1" & (is.na(sh_01)) ~ "missing",
    time_point == "Round 1" ~ "answered",
    time_point == "Round 2" & (sh_01 %in% c(-99, -999999)) ~ "dont_know",
    time_point == "Round 2" & (is.na(sh_01)) ~ "missing",
    time_point == "Round 2" ~ "answered",
    TRUE ~ NA_character_
  )) %>%
  mutate(water = with(list(
    `%in%` = function(x, table) ifelse(is.na(x), NA, base::`%in%`(x, table)),
    sh_02 = replace(sh_02, sh_02 %in% c(-99, -999999), NA_real_)
  ), case_when(
    time_point == "Round 1" & is.na(sh_02 == "1") ~ NA_real_,
    time_point == "Round 1" & (sh_02 == "1") ~ 1,
    time_point == "Round 1" ~ 0,
    time_point == "Round 2" & is.na(sh_02 == "1") ~ NA_real_,
    time_point == "Round 2" & (sh_02 == "1") ~ 1,
    time_point == "Round 2" ~ 0,
    TRUE ~ NA_real_
  ))) %>%
  mutate(water__status = case_when(
    time_point == "Round 1" & (sh_02 %in% c(-99, -999999)) ~ "dont_know",
    time_point == "Round 1" & (is.na(sh_02)) ~ "missing",
    time_point == "Round 1" ~ "answered",
    time_point == "Round 2" & (sh_02 %in% c(-99, -999999)) ~ "dont_know",
    time_point == "Round 2" & (is.na(sh_02)) ~ "missing",
    time_point == "Round 2" ~ "answered",
    TRUE ~ NA_character_
  )) %>%
  mutate(vaccine_fridge = with(list(
    `%in%` = function(x, table) ifelse(is.na(x), NA, base::`%in%`(x, table)),
    cc_01 = replace(cc_01, cc_01 %in% c(-99, -999999), NA_real_)
  ), case_when(
    time_point == "Round 1" & is.na(cc_01 == "1") ~ NA_real_,
    time_point == "Round 1" & (cc_01 == "1") ~ 1,
    time_point == "Round 1" ~ 0,
    time_point == "Round 2" & is.na(cc_01 == "1") ~ NA_real_,
    time_point == "Round 2" & (cc_01 == "1") ~ 1,
    time_point == "Round 2" ~ 0,
    TRUE ~ NA_real_
  ))) %>%
  mutate(vaccine_fridge__status = case_when(
    time_point == "Round 1" & (cc_01 %in% c(-99, -999999)) ~ "dont_know",
    time_point == "Round 1" & (is.na(cc_01)) ~ "missing",
    time_point == "Round 1" ~ "answered",
    time_point == "Round 2" & (cc_01 %in% c(-99, -999999)) ~ "dont_know",
    time_point == "Round 2" & (is.na(cc_01)) ~ "missing",
    time_point == "Round 2" ~ "answered",
    TRUE ~ NA_character_
  )) %>%
  mutate(oxytocin = with(list(
    `%in%` = function(x, table) ifelse(is.na(x), NA, base::`%in%`(x, table)),
    sh_03 = replace(sh_03, sh_03 %in% c(-99, -999999), NA_real_)
  ), case_when(
    time_point == "Round 1" & is.na(sh_03 %in% c("a", "b")) ~ NA_real_,
    time_point == "Round 1" & (sh_03 %in% c("a", "b")) ~ 1,
    time_point == "Round 1" ~ 0,
    time_point == "Round 2" & is.na(sh_03 %in% c("a", "b")) ~ NA_real_,
    time_point == "Round 2" & (sh_03 %in% c("a", "b")) ~ 1,
    time_point == "Round 2" ~ 0,
    TRUE ~ NA_real_
  ))) %>%
  mutate(oxytocin__status = case_when(
    time_point == "Round 1" & (sh_03 %in% c(-99, -999999)) ~ "dont_know",
    time_point == "Round 1" & (is.na(sh_03)) ~ "missing",
    time_point == "Round 1" ~ "answered",
    time_point == "Round 2" & (sh_03 %in% c(-99, -999999)) ~ "dont_know",
    time_point == "Round 2" & (is.na(sh_03)) ~ "missing",
    time_point == "Round 2" ~ "answered",
    TRUE ~ NA_character_
  )) %>%
  mutate(amoxicillin = with(list(
    `%in%` = function(x, table) ifelse(is.na(x), NA, base::`%in%`(x, table)),
    sh_04 = replace(sh_04, sh_04 %in% c(-99, -999999), NA_real_)
  ), case_when(
    time_point == "Round 1" & is.na(sh_04 %in% c("a", "b")) ~ NA_real_,
    time_point == "Round 1" & (sh_04 %in% c("a", "b")) ~ 1,
    time_point == "Round 1" ~ 0,
    time_point == "Round 2" & is.na(sh_04 %in% c("a", "b")) ~ NA_real_,
    time_point == "Round 2" & (sh_04 %in% c("a", "b")) ~ 1,
    time_point == "Round 2" ~ 0,
    TRUE ~ NA_real_
  ))) %>%
  mutate(amoxicillin__status = case_when(
    time_point == "Round 1" & (sh_04 %in% c(-99, -999999)) ~ "dont_know",
    time_point == "Round 1" & (is.na(sh_04)) ~ "missing",
    time_point == "Round 1" ~ "answered",
    time_point == "Round 2" & (sh_04 %in% c(-99, -999999)) ~ "dont_know",
    time_point == "Round 2" & (is.na(sh_04)) ~ "missing",
    time_point == "Round 2" ~ "answered",
    TRUE ~ NA_character_
  )) %>%
  mutate(midwives = with(list(
    `%in%` = function(x, table) ifelse(is.na(x), NA, base::`%in%`(x, table)),
    st_01 = replace(st_01, st_01 %in% c(-99, -999999), NA_real_)
  ), case_when(
    time_point == "Round 1" ~ st_01,
    time_point == "Round 2" ~ st_01,
    TRUE ~ NA_real_
  ))) %>%
  mutate(midwives__status = case_when(
    time_point == "Round 1" & (st_01 %in% c(-99, -999999)) ~ "dont_know",
    time_point == "Round 1" & (is.na(st_01)) ~ "missing",
    time_point == "Round 1" ~ "answered",
    time_point == "Round 2" & (st_01 %in% c(-99, -999999)) ~ "dont_know",
    time_point == "Round 2" & (is.na(st_01)) ~ "missing",
    time_point == "Round 2" ~ "answered",
    TRUE ~ NA_character_
  )) %>%
  mutate(nurses = with(list(
    `%in%` = function(x, table) ifelse(is.na(x), NA, base::`%in%`(x, table)),
    st_02 = replace(st_02, st_02 %in% c(-99, -999999), NA_real_)
  ), case_when(
    time_point == "Round 1" ~ st_02,
    time_point == "Round 2" ~ st_02,
    TRUE ~ NA_real_
  ))) %>%
  mutate(nurses__status = case_when(
    time_point == "Round 1" & (st_02 %in% c(-99, -999999)) ~ "dont_know",
    time_point == "Round 1" & (is.na(st_02)) ~ "missing",
    time_point == "Round 1" ~ "answered",
    time_point == "Round 2" & (st_02 %in% c(-99, -999999)) ~ "dont_know",
    time_point == "Round 2" & (is.na(st_02)) ~ "missing",
    time_point == "Round 2" ~ "answered",
    TRUE ~ NA_character_
  )) %>%
  mutate(offers_delivery = with(list(
    `%in%` = function(x, table) ifelse(is.na(x), NA, base::`%in%`(x, table)),
    sv_01_del = replace(sv_01_del, sv_01_del %in% c(-99, -999999), NA_real_)
  ), case_when(
    time_point == "Round 1" & is.na(sv_01_del == 1) ~ NA_real_,
    time_point == "Round 1" & (sv_01_del == 1) ~ 1,
    time_point == "Round 1" ~ 0,
    time_point == "Round 2" & is.na(sv_01_del == 1) ~ NA_real_,
    time_point == "Round 2" & (sv_01_del == 1) ~ 1,
    time_point == "Round 2" ~ 0,
    TRUE ~ NA_real_
  ))) %>%
  mutate(offers_delivery__status = case_when(
    time_point == "Round 1" & (sv_01_del %in% c(-99, -999999)) ~ "dont_know",
    time_point == "Round 1" & (is.na(sv_01_del)) ~ "missing",
    time_point == "Round 1" ~ "answered",
    time_point == "Round 2" & (sv_01_del %in% c(-99, -999999)) ~ "dont_know",
    time_point == "Round 2" & (is.na(sv_01_del)) ~ "missing",
    time_point == "Round 2" ~ "answered",
    TRUE ~ NA_character_
  )) %>%
  mutate(offers_fp = with(list(
    `%in%` = function(x, table) ifelse(is.na(x), NA, base::`%in%`(x, table)),
    sv_01_fp = replace(sv_01_fp, sv_01_fp %in% c(-99, -999999), NA_real_)
  ), case_when(
    time_point == "Round 1" & is.na(sv_01_fp == 1) ~ NA_real_,
    time_point == "Round 1" & (sv_01_fp == 1) ~ 1,
    time_point == "Round 1" ~ 0,
    time_point == "Round 2" & is.na(sv_01_fp == 1) ~ NA_real_,
    time_point == "Round 2" & (sv_01_fp == 1) ~ 1,
    time_point == "Round 2" ~ 0,
    TRUE ~ NA_real_
  ))) %>%
  mutate(offers_fp__status = case_when(
    time_point == "Round 1" & (sv_01_fp %in% c(-99, -999999)) ~ "dont_know",
    time_point == "Round 1" & (is.na(sv_01_fp)) ~ "missing",
    time_point == "Round 1" ~ "answered",
    time_point == "Round 2" & (sv_01_fp %in% c(-99, -999999)) ~ "dont_know",
    time_point == "Round 2" & (is.na(sv_01_fp)) ~ "missing",
    time_point == "Round 2" ~ "answered",
    TRUE ~ NA_character_
  ))

# Select only indicator columns
indicator_cols <- c("electricity", "water", "vaccine_fridge", "oxytocin", "amoxicillin", "midwives", "nurses", "offers_delivery", "offers_fp")
results_final <- results %>%
  select(all_of(indicator_cols))

# Create indicator metadata mapping (category, type, aggregation)
indicator_metadata <- data.frame(
  hfa_indicator = c("electricity", "water", "vaccine_fridge", "oxytocin", "amoxicillin", "midwives", "nurses", "offers_delivery", "offers_fp"),
  hfa_category = c("infra", "infra", "infra", "meds", "meds", "staff", "staff", "serv", "serv"),
  hfa_sub_category = c("power_water", "power_water", "cold_chain", "tracer", "tracer", "hr", "hr", "offered", "offered"),
  hfa_service_category = c("general", "general", "child", "mnh", "child", "mnh", "general", "mnh", "mnh"),
  hfa_short_label = c("Electricity", "Improved water", "Vaccine fridge", "Oxytocin", "Amoxicillin", "Midwives", "Nurses", "Delivery services", "Family planning"),
  ind_type = c("binary", "binary", "binary", "binary", "binary", "numeric", "numeric", "binary", "binary"),
  ind_aggregation = c("avg", "avg", "avg", "avg", "avg", "sum", "sum", "avg", "avg")
)

# Pivot back to long format and add metadata
facility_info <- data_wide %>%
  select(all_of(facility_cols))

results_long <- facility_info %>%
  bind_cols(data_wide %>% select(weight_final)) %>%
  bind_cols(results_final) %>%
  pivot_longer(
    cols = all_of(indicator_cols),
    names_to = "hfa_indicator",
    values_to = "raw_value"
  ) %>%
  left_join(indicator_metadata, by = "hfa_indicator") %>%
  filter(!is.na(raw_value)) %>%
  mutate(
    sum_val    = ifelse(ind_aggregation == "sum", raw_value * weight_final, NA_real_),
    avg_num    = ifelse(ind_aggregation == "avg", raw_value * weight_final, NA_real_),
    avg_weight = ifelse(ind_aggregation == "avg", weight_final, NA_real_)
  ) %>%
  select(-raw_value, -weight_final, -hfa_short_label, -ind_type, -ind_aggregation)

if (nrow(results_long) == 0) {
  stop("No results generated - all indicator values are NA. Check that HFA indicators have been configured with R code.")
}

# Write output
write.csv(results_long, "M10_hfa_results.csv", row.names = FALSE)

# Carried variant: fill rounds where an indicator has no observed values at
# all (question not asked that round) by duplicating the donor round's
# facility rows. Previous-first; leading gaps backfill from the next
# observed round. Filled rounds exactly reproduce donor aggregates.
time_point_order <- c("Round 1", "Round 2")
data_tps <- unique(as.character(data_wide$time_point))
extra_tps <- setdiff(data_tps, time_point_order)
if (length(extra_tps) > 0) {
  warning(paste0(
    "Time points in data but missing from instance time-point order (appended at end): ",
    paste(sort(extra_tps), collapse = ", ")
  ))
  time_point_order <- c(time_point_order, sort(extra_tps))
}
ordered_tps <- time_point_order[time_point_order %in% data_tps]

carried_new_rows <- list()
for (ind in unique(results_long$hfa_indicator)) {
  ind_rows <- results_long %>% filter(hfa_indicator == ind)
  obs_idx <- which(ordered_tps %in% unique(ind_rows$time_point))
  for (i in setdiff(seq_along(ordered_tps), obs_idx)) {
    prev_obs <- obs_idx[obs_idx < i]
    donor_idx <- if (length(prev_obs) > 0) max(prev_obs) else min(obs_idx[obs_idx > i])
    carried_new_rows[[length(carried_new_rows) + 1]] <- ind_rows %>%
      filter(time_point == ordered_tps[donor_idx]) %>%
      mutate(carried_from = time_point, time_point = ordered_tps[i])
  }
}

results_carried <- bind_rows(
  results_long %>% mutate(carried_from = NA_character_),
  bind_rows(carried_new_rows)
)
write.csv(results_carried, "M10_hfa_results_carried.csv", row.names = FALSE)

# Response-status companion output: share of facilities answering don't-know /
# missing / not-applicable per indicator. The __status columns are emitted by
# the server-side script generator; without them (older server) write a
# header-only file so ingestion still succeeds.
status_cols <- names(results)[grepl("__status$", names(results))]
if (length(status_cols) > 0) {
  status_long <- facility_info %>%
    bind_cols(data_wide %>% select(weight_final)) %>%
    bind_cols(results %>% select(all_of(status_cols))) %>%
    pivot_longer(
      cols = all_of(status_cols),
      names_to = "hfa_indicator",
      values_to = "response_status"
    ) %>%
    mutate(hfa_indicator = sub("__status$", "", hfa_indicator)) %>%
    left_join(indicator_metadata, by = "hfa_indicator") %>%
    filter(!is.na(response_status)) %>%
    mutate(
      dk_num       = (response_status == "dont_know") * weight_final,
      missing_num  = (response_status == "missing") * weight_final,
      answered_num = (response_status == "answered") * weight_final,
      na_num       = (response_status == "not_applicable") * weight_final,
      resp_weight  = (response_status != "not_applicable") * weight_final,
      total_weight = weight_final
    ) %>%
    select(-response_status, -weight_final, -hfa_short_label, -ind_type, -ind_aggregation)
  write.csv(status_long, "M10_hfa_response_status.csv", row.names = FALSE)
} else {
  writeLines(
    "facility_id,admin_area_4,admin_area_3,admin_area_2,admin_area_1,hfa_indicator,hfa_category,hfa_sub_category,hfa_service_category,time_point,dk_num,missing_num,answered_num,na_num,resp_weight,total_weight",
    "M10_hfa_response_status.csv"
  )
}

# Variant breakdown output: a SEPARATE pipeline from the main results (own
# metadata frame, own select/pivot/write), so the main output stays untouched
# and the carried loop above never sees variant rows. Parent/item routing is
# metadata-driven via variant_col — composed column names are never parsed
# apart. Per-item denominators legitimately differ: each item gates on its own
# expression's NA.
variant_cols <- c()
if (length(variant_cols) > 0) {
  results_variants <- results %>%
  identity()
  variant_metadata <- data.frame(
  variant_col = character(0),
  hfa_indicator = character(0),
  hfa_variant_item = character(0),
  hfa_category = character(0),
  hfa_sub_category = character(0),
  hfa_service_category = character(0),
  ind_aggregation = character(0)
  )
  variants_long <- facility_info %>%
    bind_cols(data_wide %>% select(weight_final)) %>%
    bind_cols(results_variants %>% select(all_of(variant_cols))) %>%
    pivot_longer(
      cols = all_of(variant_cols),
      names_to = "variant_col",
      values_to = "raw_value"
    ) %>%
    left_join(variant_metadata, by = "variant_col") %>%
    filter(!is.na(raw_value)) %>%
    mutate(
      sum_val    = ifelse(ind_aggregation == "sum", raw_value * weight_final, NA_real_),
      avg_num    = ifelse(ind_aggregation == "avg", raw_value * weight_final, NA_real_),
      avg_weight = ifelse(ind_aggregation == "avg", weight_final, NA_real_)
    ) %>%
    select(-variant_col, -raw_value, -weight_final, -ind_aggregation)
  write.csv(variants_long, "M10_hfa_results_variants.csv", row.names = FALSE)

  # Carried twin: the main carried loop's donor rule, applied per
  # (indicator, variant item) pair.
  variant_pairs <- variants_long %>% distinct(hfa_indicator, hfa_variant_item)
  variants_carried_new_rows <- list()
  for (pi in seq_len(nrow(variant_pairs))) {
    pair_rows <- variants_long %>%
      filter(
        hfa_indicator == variant_pairs$hfa_indicator[pi],
        hfa_variant_item == variant_pairs$hfa_variant_item[pi]
      )
    obs_idx <- which(ordered_tps %in% unique(pair_rows$time_point))
    for (i in setdiff(seq_along(ordered_tps), obs_idx)) {
      prev_obs <- obs_idx[obs_idx < i]
      donor_idx <- if (length(prev_obs) > 0) max(prev_obs) else min(obs_idx[obs_idx > i])
      variants_carried_new_rows[[length(variants_carried_new_rows) + 1]] <- pair_rows %>%
        filter(time_point == ordered_tps[donor_idx]) %>%
        mutate(carried_from = time_point, time_point = ordered_tps[i])
    }
  }
  variants_carried <- bind_rows(
    variants_long %>% mutate(carried_from = NA_character_),
    bind_rows(variants_carried_new_rows)
  )
  write.csv(variants_carried, "M10_hfa_results_variants_carried.csv", row.names = FALSE)
} else {
  # Header-only, with the instance's actual facility/admin columns.
  variants_empty <- results_long[0, ] %>% mutate(hfa_variant_item = character(0))
  write.csv(variants_empty, "M10_hfa_results_variants.csv", row.names = FALSE)
  variants_carried_empty <- variants_empty %>% mutate(carried_from = character(0))
  write.csv(variants_carried_empty, "M10_hfa_results_variants_carried.csv", row.names = FALSE)
}

print("HFA script completed successfully!")
